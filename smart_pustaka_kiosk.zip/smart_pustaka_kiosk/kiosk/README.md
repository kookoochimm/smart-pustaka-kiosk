# SMART PUSTAKA RFID Kiosk

React + Vite frontend for the TVETMARA Sungai Petani RFID self-service kiosk.

## Flow

1. `tapcard` - user taps RFID card.
2. Backend checks `users.uid`.
3. If the user exists, the interface changes automatically to `tapbook`.
4. `tapbook` - user taps the RFID sticker on a book.
5. Backend checks `books.uid`.
6. If the book has an active borrow (`borrow.return_date IS NULL`) belonging to the current user, it is returned.
7. If the book has an active borrow belonging to another user, an error is shown.
8. If the book is available and the user has no unpaid fine, a new row is inserted into `borrow` and the interface changes to `borrow`.
9. On return, the existing `borrow` row is updated with `return_date`. The database triggers calculate `late_days` and `fine`, and update `books.status` to `returned`.

## Database field names

The frontend/backend follow the current `library_db` schema:

- User: `user_id`, `uid`, `fullname`, `username`, `matric_number`, `role`, `program`
- Book: `book_id`, `uid`, `title`, `author`, `call_number`, `program`, `status`
- Borrow: `borrow_id`, `user_id`, `book_id`, `borrow_date`, `due_date`, `return_date`, `late_days`, `fine`, `payment_status`

There is no `nickname`, `programm`, `course`, or `category` field in the current database.

## Run

```bash
npm install
npm run dev
```

Default API:
```text
http://localhost:5000/api
```

To change it, create `.env` in this folder:

```env
VITE_API_URL=http://localhost:5000/api
```
